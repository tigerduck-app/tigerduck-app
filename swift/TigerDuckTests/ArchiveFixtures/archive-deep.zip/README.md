Office hours moved to Thursday.
